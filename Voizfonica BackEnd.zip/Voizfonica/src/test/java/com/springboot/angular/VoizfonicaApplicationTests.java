package com.springboot.angular;


import static org.junit.jupiter.api.Assertions.assertEquals;


import java.util.List;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.springboot.angular.model.LoginUser;
import com.springboot.angular.repo.AdminUserRepo;
import com.springboot.angular.repo.LoginUserRepo;
import com.springboot.angular.repo.RegisterUserRepo;
import com.springboot.angular.service.AdminService;

@RunWith(SpringRunner.class)
@SpringBootTest
class VoizfonicaApplicationTests {
	
	
	@MockBean
	private LoginUserRepo repo;
	@MockBean
	private RegisterUserRepo repo1;
	
	@MockBean
	private AdminUserRepo repository;
	
	@MockBean
	private AdminService service;
	
	@Before
	public void setUp() {
		LoginUser alex = new LoginUser("alex");

	    Mockito.when(repo.findByUserId(alex.getUserId()))
	      .thenReturn(alex);
	}
	
	@Test
	public void loginUserTest() {
		String name = "alex";
	    assertEquals(name, name);
	}
	
	@Test
	public void saveRegisterUserTest() {
		
		   LoginUser user=new LoginUser("Divya","123","Divya","divya@gmail.com","9034567218","123","female");
			Mockito.when(repo.save(user)).thenReturn(user);
		assertEquals(user,user);
	}
	
	
	
	@Test
	public void adminSaveUsersTest() {
		LoginUser user1=new LoginUser("Grace","123","Grace","Grace@gmail.com","9034567218","123","female");
		Mockito.when(repository.save(user1)).thenReturn(user1);
		assertEquals(user1,user1);
	}
	
	@Test
	public void adminGetOneUserTest() {
		LoginUser user = new LoginUser("Clara");
	    Mockito.when(repository.findByUserId("Clara"))
	     .thenReturn(user);
	    assertEquals(user, user);
	}
	
	@Test
	public void adminDeleteUserTest() {
		String user="Priya";
		service.deleteUser(user);
		assertEquals(1, 1);
	}

}
