package com.springboot.angular.service;

import java.util.List;

import com.springboot.angular.model.LoginUser;

public interface AdminService {

	String saveUser(LoginUser user);
	void updateUser(LoginUser user);
	void deleteUser(String id);
	LoginUser getOneUser(String id);
	List<LoginUser> getAllUsers();
	public boolean isExist(String pid);
}
