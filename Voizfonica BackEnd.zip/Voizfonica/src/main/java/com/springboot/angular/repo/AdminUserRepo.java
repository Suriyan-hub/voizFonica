package com.springboot.angular.repo;



import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.angular.model.LoginUser;

public interface AdminUserRepo extends JpaRepository<LoginUser, String>{

	Object findByUserId(String string);

}
