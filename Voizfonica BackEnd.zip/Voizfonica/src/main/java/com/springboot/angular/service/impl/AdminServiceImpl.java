package com.springboot.angular.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.angular.model.LoginUser;
import com.springboot.angular.repo.AdminUserRepo;
import com.springboot.angular.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminUserRepo repo;
	
	@Override
	public String saveUser(LoginUser user) {
		// TODO Auto-generated method stub
		user=repo.save(user);
		return user.getUserId(); 
		
	}

	@Override
	public void updateUser(LoginUser user) {
		// TODO Auto-generated method stub
		repo.save(user);

	}

	@Override
	public void deleteUser(String id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);

	}

	@Override
	public LoginUser getOneUser(String id) {
		// TODO Auto-generated method stub
		Optional<LoginUser> opt = repo.findById(id);
		if(opt.isPresent()) {
			return opt.get();
		}
		return null;
		
	}

	@Override
	public List<LoginUser> getAllUsers() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public boolean isExist(String id) {
		// TODO Auto-generated method stub
		return repo.existsById(id);
	}

}
