package com.springboot.angular.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="loginuser")

public class LoginUser 
{
	@Id
	private String userId;
	private String password;
	private String name;
	private String  email;
	private String  phone;
	private String  cpassword;
	private String  gender;
	private int cPlanId;
	private boolean enabled;
	
	
	public boolean isEnabled() {
		return enabled;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getCpassword() {
		return cpassword;
	}
	public void setCpassword(String cpassword) {
		this.cpassword = cpassword;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getcPlanId() {
		return cPlanId;
	}
	public void setcPlanId(int cPlanId) {
		this.cPlanId = cPlanId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public LoginUser(String userId, String password) {
		super();
		this.userId = userId;
		this.password = password;
	}
	public LoginUser() {
		super();
	}
	
	public LoginUser(String userId) {
		super();
		this.userId = userId;
	}
	public LoginUser(String userId, String password, String name, String email, String phone, String cpassword,
			String gender) {
		super();
		this.userId = userId;
		this.password = password;
		this.name = name;
		this.email = email;
		this.phone = phone;
		this.cpassword = cpassword;
		this.gender = gender;
	}
	public LoginUser(String name, String email, String phone, String cpassword, String gender,int cPlanId,boolean enabled)
	{
		super();
		this.name = name;
		this.email = email;
		this.phone = phone;
		this.cpassword = cpassword;
		this.gender = gender;
		this.cPlanId=cPlanId;
		this.enabled = enabled;
		
	}
	@Override
	public String toString() {
		return "LoginUser [userId=" + userId + ", password=" + password + "]";
	}
	public Object thenReturn(LoginUser user) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
