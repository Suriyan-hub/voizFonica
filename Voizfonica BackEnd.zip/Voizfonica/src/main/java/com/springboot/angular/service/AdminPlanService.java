package com.springboot.angular.service;

import java.util.List;


import com.springboot.angular.model.RechargePlan;

public interface AdminPlanService {
	int savePlan(RechargePlan plan);
	void updatePlan(RechargePlan plan);
	void deletePlan(int id);
	RechargePlan getOnePlan(int id);
	List<RechargePlan> getAllPlans();
	public boolean isExist(int uid);
}
