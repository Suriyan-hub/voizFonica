package com.springboot.angular.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.angular.repo.RegisterUserRepo;

@Service
public class RegistrationService {
	
	@Autowired
	private RegisterUserRepo repo;
	public void setCurrentPlan(String userId, Integer planId) {
		repo.setCurrentPlan(userId, planId);
	}
}
