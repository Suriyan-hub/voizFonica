package com.springboot.angular.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springboot.angular.model.Admin;
import com.springboot.angular.model.LoginUser;

@Repository
public interface AdminLoginRepo extends JpaRepository<Admin, String>{

	Admin findByUsername(String username);
}
