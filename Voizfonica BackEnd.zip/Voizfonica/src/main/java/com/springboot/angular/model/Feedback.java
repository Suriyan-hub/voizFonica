package com.springboot.angular.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;



@Entity
public class Feedback {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int feedbackId;
	private String name;
	private String emailId;
	private String Customer_Support;
	private String Value_For_Money;
	private String Your_Opinion;
	public Feedback() {
		super();
	}
	public int getFeedbackId() {
		return feedbackId;
	}
	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getCustomer_Support() {
		return Customer_Support;
	}
	public void setCustomer_Support(String customer_Support) {
		Customer_Support = customer_Support;
	}
	public String getValue_For_Money() {
		return Value_For_Money;
	}
	public void setValue_For_Money(String value_For_Money) {
		Value_For_Money = value_For_Money;
	}
	public String getYour_Opinion() {
		return Your_Opinion;
	}
	public void setYour_Opinion(String your_Opinion) {
		Your_Opinion = your_Opinion;
	}
	public Feedback(int feedbackId, String name, String emailId, String customer_Support, String value_For_Money,
			String your_Opinion) {
		super();
		this.feedbackId = feedbackId;
		this.name = name;
		this.emailId = emailId;
		Customer_Support = customer_Support;
		Value_For_Money = value_For_Money;
		Your_Opinion = your_Opinion;
	}
	
	
}