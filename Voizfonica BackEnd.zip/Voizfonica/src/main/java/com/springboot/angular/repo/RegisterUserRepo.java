package com.springboot.angular.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.springboot.angular.model.LoginUser;

@Repository
public interface RegisterUserRepo extends JpaRepository<LoginUser, String>{

	@Query("update LoginUser u set u.cPlanId=?2 where u.userId=?1")
	@Modifying
	public void setCurrentPlan(String userId,Integer planId);
}
