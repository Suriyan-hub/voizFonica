package com.springboot.angular.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.springboot.angular.model.Feedback;
import com.springboot.angular.repo.FeedbackRepository;



@Service
@Transactional
public class FeedbackService {
	@Autowired
	FeedbackRepository feedbackRepo;
	
	public Feedback saveFeedback(Feedback feedback) {
		feedbackRepo.save(feedback);
		return feedback;
	}
	public List<Feedback> getAllFeedbacks(){
		return feedbackRepo.findAll();
	}
}