package com.springboot.angular.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.angular.model.RechargePlan;

public interface AdminPlanRepo extends JpaRepository<RechargePlan, Integer>{

}
