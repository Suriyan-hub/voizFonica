package com.springboot.angular.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.springboot.angular.model.RechargePlan;
import com.springboot.angular.repo.RechargePlanRepository;

@Service
@Transactional
public class RechargeService {
	@Autowired
	private RechargePlanRepository planRepo;
	
	public RechargePlan savePlan(RechargePlan plan) {
		return planRepo.save(plan);
	}
	public Optional<RechargePlan> fetchRechargePlanByPlanId(int planId) {
		return planRepo.findById(planId);
	}
	public List<RechargePlan> fetchRechargePlanByServiceType(String serviceType) {
		return planRepo.findByServiceType(serviceType);
	}
}