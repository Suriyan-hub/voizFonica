package com.springboot.angular;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VoizfonicaApplication {

	public static void main(String[] args) {
		SpringApplication.run(VoizfonicaApplication.class, args);
	}

}
