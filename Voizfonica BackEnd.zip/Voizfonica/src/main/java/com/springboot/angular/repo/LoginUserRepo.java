package com.springboot.angular.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springboot.angular.model.LoginUser;

@Repository
public interface LoginUserRepo extends JpaRepository<LoginUser, String> {

	LoginUser findByUserId(String userId);

	

	

}
