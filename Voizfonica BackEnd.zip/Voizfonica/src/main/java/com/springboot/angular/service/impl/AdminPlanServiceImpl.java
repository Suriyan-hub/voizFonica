package com.springboot.angular.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.angular.model.RechargePlan;
import com.springboot.angular.repo.AdminPlanRepo;
import com.springboot.angular.service.AdminPlanService;

@Service
public class AdminPlanServiceImpl implements AdminPlanService {
	
	@Autowired
	private AdminPlanRepo repo;

	@Override
	public int savePlan(RechargePlan plan) {
		// TODO Auto-generated method stub
		plan=repo.save(plan);
		return plan.getPlanId();
	}

	@Override
	public void updatePlan(RechargePlan plan) {
		// TODO Auto-generated method stub
		repo.save(plan);

	}

	@Override
	public void deletePlan(int id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);

	}

	@Override
	public RechargePlan getOnePlan(int id) {
		// TODO Auto-generated method stub
		Optional<RechargePlan> opt=repo.findById(id);
		if(opt.isPresent()) {
			return opt.get();
		}
		return null;
	}

	@Override
	public List<RechargePlan> getAllPlans() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public boolean isExist(int pid) {
		// TODO Auto-generated method stub
		return repo.existsById(pid);
	}

}
