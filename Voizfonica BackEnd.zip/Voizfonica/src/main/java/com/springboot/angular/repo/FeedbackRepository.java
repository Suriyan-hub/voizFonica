package com.springboot.angular.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springboot.angular.model.Feedback;



@Repository
public interface FeedbackRepository extends JpaRepository<Feedback, Integer>{

}